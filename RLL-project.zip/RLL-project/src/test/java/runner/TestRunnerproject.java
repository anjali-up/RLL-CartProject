package runner;
import org.testng.annotations.Listeners;

import Utilities.ItestListenerclass;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features ="C:\\Users\\anjali upadhyay\\Downloads\\eclips-java-developer\\RLL-project\\src\\test\\java\\features",
        glue = "stepDef",
        plugin = {"pretty","html:target/cucumber-reports/cucumber-preety"},
		
		//"return:target/cucumber-reports/return.txt"})
       monochrome = true
       )

@Listeners(ItestListenerclass.class)
public class TestRunnerproject extends AbstractTestNGCucumberTests {
}